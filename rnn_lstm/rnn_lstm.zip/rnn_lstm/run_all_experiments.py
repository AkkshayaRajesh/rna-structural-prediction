import torch
from torch.utils.data import DataLoader
import pandas as pd
import numpy as np
from train_rnn import RNNModel
from train_lstm import LSTMModel
from dataset import RNADataset, collate_rna_batch
from evaluate import compare_pair_matrices
from decoder import greedy_decode, pairs_to_matrix

# Utility function to split the loaded DataFrame
def split_data(df, val_ratio=0.2, seed=42):
    np.random.seed(seed)
    # Shuffle the indices
    shuffled_indices = np.random.permutation(len(df))
    val_size = int(len(df) * val_ratio)
    
    val_indices = shuffled_indices[:val_size]
    train_indices = shuffled_indices[val_size:]
    
    train_df = df.iloc[train_indices].reset_index(drop=True)
    val_df = df.iloc[val_indices].reset_index(drop=True)
    
    return train_df, val_df


# training function 
def train_model(model_class, train_dataset, val_dataset, save_path, epochs=20, batch_size=8):

    loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_rna_batch)
    val_loader = DataLoader(val_dataset, batch_size=1, shuffle=False, collate_fn=collate_rna_batch) 
   
    model = model_class()
    opt = torch.optim.Adam(model.parameters(), lr=1e-2)
    loss_fn = torch.nn.BCEWithLogitsLoss()

    best_val_f1 = -1.0 
    best_model_state = None

    print(f"\n===== Training {save_path} =====")

    patience = 5
    patience_counter = 0
    for ep in range(epochs):
        # training
        model.train() 
        total_train_loss = 0.0
        for X, mask, Y in loader:
           
            pred = model(X)
            mask2d = (mask.unsqueeze(1)& mask.unsqueeze(2)).bool()
            active_preds = pred[mask2d]
            active_targets = Y[mask2d]
            loss = loss_fn(active_preds, active_targets)

            opt.zero_grad()
            loss.backward()
            opt.step()
            total_train_loss += loss.item()

        print(f"Epoch {ep+1}/{epochs} - Train Loss: {total_train_loss:.4f}")
        

        # validation
        model.eval() 
        val_f1_sum = 0
        val_count = 0
        
        with torch.no_grad():
            for X, mask, Y in val_loader:
                
                L = mask.sum().item()
                pred = model(X)[0]
                prob_mat = torch.sigmoid(pred[:L, :L])
                
                score_mat = (prob_mat * 100).int()
                predicted_pairs = greedy_decode(score_mat)
                pred_mat_np = pairs_to_matrix(predicted_pairs, L)
                pred_bin = torch.from_numpy(pred_mat_np).float()
                true_mat = Y[0, :L, :L]
                
                metrics = compare_pair_matrices(true_mat, pred_bin)
                val_f1_sum += metrics["F1"]
                val_count += 1
        
        current_val_f1 = val_f1_sum / val_count
        print(f"Epoch {ep+1}/{epochs} - VAL Macro F1: {current_val_f1:.4f}")
        
       
        # stop when best model
        if current_val_f1 > best_val_f1:
            best_val_f1 = current_val_f1
            best_model_state = model.state_dict()
            patience_counter = 0 
            print(">>> New best model found on validation set. Saving weights.")
        else :
            patience_counter += 1 
            print(f"Patience: {patience_counter}/{patience}")
        
        if patience_counter >= patience:
            print(f"Early stopping at epoch {ep+1} as validation F1 has not improved for {patience} epochs.")
            break # exit the training loop 

    # the best performing model (determined by validation F1)
    if best_model_state:
        torch.save(best_model_state, save_path)
        print(f"Saved BEST model (VAL F1: {best_val_f1:.4f}) → {save_path}")
        model.load_state_dict(best_model_state)
    
    return model

# evaluate
def evaluate(model_class, model_path, test_dataset):

    model = model_class()
    model.load_state_dict(torch.load(model_path, map_location="cpu"))
    model.eval()

    dataset = test_dataset
    loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_rna_batch)

    total_prec = total_rec = total_f1 = 0
    total_tp =  total_fp = total_fn = 0 

    N = len(dataset)

    for X, mask, Y in loader:

        with torch.no_grad():
            pred = model(X)[0]         

        L = mask.sum().item()
        prob_mat = torch.sigmoid(pred[:L, :L])

        # decoding using nussinov
        score_mat = (prob_mat * 100).int()   
        predicted_pairs = greedy_decode(score_mat) # tried two decoder 

        pred_mat_np = pairs_to_matrix(predicted_pairs, L)
        pred_bin = torch.from_numpy(pred_mat_np).float()

        true_mat = Y[0, :L, :L]

        metrics = compare_pair_matrices(true_mat, pred_bin)

        total_prec += metrics["Precision"]
        total_rec  += metrics["Recall"]
        total_f1   += metrics["F1"]
        total_tp += metrics["TP"]
        total_fp += metrics["FP"]
        total_fn += metrics["FN"]

    return total_prec / N, total_rec / N, total_f1 / N, total_tp, total_fp, total_fn


# main pipeline
if __name__ == "__main__":

    # dataset paths
    arch_train = "./data/archivell/Train.csv"
    arch_test  = "./data/archivell/Test.csv"

    # bprna_train = "./data/bprna/Train.csv"
    # bprna_test  = "./data/bprna/Test.csv"

    models = {
        "rnn_arch":  (RNNModel,  arch_train,  arch_test,  "rnn_archivell.pt"),
        # Add more if needed:
        "lstm_arch": (LSTMModel, arch_train,  arch_test,  "lstm_archivell.pt"),
        # "rnn_bprna": (RNNModel,  bprna_train, bprna_test, "rnn_bprna.pt"),
        # "lstm_bprna":(LSTMModel, bprna_train, bprna_test, "lstm_bprna.pt"),
    }
    archive_df = pd.read_csv(arch_train)
    results = []

    for name, (model_cls, train_csv, test_csv, save_path) in models.items():
        train_df, val_df = split_data(archive_df, val_ratio=0.2)
        
        train_dataset = RNADataset(train_df)
        val_dataset = RNADataset(val_df)
        test_dataset = RNADataset(test_csv) 
        trained_model = train_model(model_cls, train_dataset, val_dataset, save_path)

        # evaluate
        P, R, F1, tp, fp, fn = evaluate(model_cls, save_path, test_dataset)
        micro_precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        micro_recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        if micro_precision + micro_recall == 0:
            micro_f1 = 0.0
        else:
            micro_f1 = 2 * (micro_precision * micro_recall) / (micro_precision + micro_recall)

        results.append([name + "_macro", P, R, F1])
        
        results.append([name + "_micro", micro_precision, micro_recall, micro_f1])

    # save summary table
    df = pd.DataFrame(results, columns=["Model", "Precision", "Recall", "F1"])
    print("\n==================== FINAL RESULTS ====================")
    print(df.to_string(index=False))

    df.to_csv("results.csv", index=False)
    print("\nSaved → results.csv")
