import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from dataset import RNADataset, collate_rna_batch


# lstm model 
class LSTMModel(nn.Module):
    def __init__(self, embed_dim=16, hidden_dim=64):
        super().__init__()
        self.embedding = nn.Embedding(5, embed_dim, padding_idx=0)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.proj = nn.Linear(hidden_dim*2, hidden_dim)

    def forward(self, x):
        emb = self.embedding(x)  
        h, _ = self.lstm(emb)  
        h2 = self.proj(h)  
        P = torch.matmul(h2, h2.transpose(1, 2))
        return P


# train 
def train_model(dataset, model_save_path, epochs=5, batch_size=4):

    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        collate_fn=collate_rna_batch
    )

    model = LSTMModel()
    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.BCEWithLogitsLoss()

    print(f"\n===== Training LSTM Model for: {model_save_path} =====")

    for epoch in range(epochs):
        total_loss = 0.0

        for input_ids, mask, targets in loader:
            pred = model(input_ids)

            active_mask = (mask.unsqueeze(1) & mask.unsqueeze(2)).bool()
            loss = criterion(pred[active_mask], targets[active_mask])

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        print(f"Epoch {epoch+1}/{epochs} | Loss = {total_loss:.4f}")

    torch.save(model.state_dict(), model_save_path)
    print(f"Model saved → {model_save_path}\n")

    return model


# train two datasets 

if __name__ == "__main__":

    # archivell training
    archive_train_path = "./data/archivell/Train.csv"
    archive_dataset = RNADataset(archive_train_path)

    train_model(
        dataset=archive_dataset,
        model_save_path="lstm_archivell.pt"
    )


    # bpRNA training
    bprna_train_path = "./data/bprna/Train.csv"
    bprna_dataset = RNADataset(bprna_train_path)

    train_model(
        dataset=bprna_dataset,
        model_save_path="lstm_bprna.pt"
    )
