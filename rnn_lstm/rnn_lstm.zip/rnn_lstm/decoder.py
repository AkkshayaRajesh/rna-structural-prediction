import numpy as np

def nussinov_decode(score_matrix):
    L = score_matrix.shape[0]
    dp = np.zeros((L, L), dtype=int)
    bt = [[None] * L for _ in range(L)]

    for k in range(1, L):
        for i in range(L - k):
            j = i + k

            best = dp[i + 1][j]
            bt_choice = (i + 1, j)

            if dp[i][j - 1] > best:
                best = dp[i][j - 1]
                bt_choice = (i, j - 1)

            pair_score = score_matrix[i][j]
            if i + 1 <= j - 1 and dp[i + 1][j - 1] + pair_score > best:
                best = dp[i + 1][j - 1] + pair_score
                bt_choice = (i + 1, j - 1, "PAIR")

            for t in range(i + 1, j):
                temp = dp[i][t] + dp[t + 1][j]
                if temp > best:
                    best = temp
                    bt_choice = (i, t, t + 1, j)

            dp[i][j] = best
            bt[i][j] = bt_choice

    pairs = []
    stack = [(0, L - 1)]

    while stack:
        i, j = stack.pop()
        if i >= j:
            continue

        choice = bt[i][j]

        if choice == (i + 1, j):
            stack.append((i + 1, j))

        elif choice == (i, j - 1):
            stack.append((i, j - 1))

        elif len(choice) == 3 and choice[2] == "PAIR":
            pairs.append((i, j))
            stack.append((i + 1, j - 1))

        else:
            li, t, tp, rj = choice
            stack.append((li, t))
            stack.append((tp, rj))

    return pairs

def pairs_to_matrix(pairs, L):
    mat = np.zeros((L, L), dtype=np.float32)
    for i, j in pairs:
        mat[i, j] = mat[j, i] = 1.0
    return mat


def greedy_decode(prob_matrix, threshold=0.5):
    """
    Fast greedy decoding.
    1. Select all pairs with p > threshold.
    2. Sort by probability (descending).
    3. Add pair if it doesn't conflict with existing pairs.
    """
    L = prob_matrix.shape[0]
    # Get indices where prob > threshold in the upper triangle
    rows, cols = np.where(np.triu(prob_matrix, k=1) > threshold)
    
    candidates = []
    for i, j in zip(rows, cols):
        candidates.append((prob_matrix[i, j], i, j))
    
    # Sort by probability descending
    candidates.sort(key=lambda x: x[0], reverse=True)
    
    paired = set()
    pairs = []
    
    for prob, i, j in candidates:
        # Check canonical base pairing rules (if necessary for RNA)
        # Check no conflicts (i or j already paired)
        if i not in paired and j not in paired:
            pairs.append((i, j))
            paired.add(i)
            paired.add(j)
            
    return pairs