import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset

# encoding
BASE2IDX = {"A": 1, "C": 2, "G": 3, "U": 4}

def encode_sequence(seq):
    seq = seq.upper().replace("T", "U")
    return torch.tensor([BASE2IDX.get(b, 0) for b in seq], dtype=torch.long)

def dotbracket_to_pairs(db):
    stack = []
    pairs = []
    for i, c in enumerate(db):
        if c == "(":
            stack.append(i)
        elif c == ")":
            if stack:  
                j = stack.pop()
                pairs.append((j, i))
    return pairs

def pairs_to_matrix(pairs, L):
    mat = np.zeros((L, L), dtype=np.float32)
    for i, j in pairs:
        mat[i, j] = 1.0
        mat[j, i] = 1.0
    return torch.tensor(mat, dtype=torch.float32)

def dotbracket_to_matrix(db):
    pairs = dotbracket_to_pairs(db)
    return pairs_to_matrix(pairs, len(db))


# generic RNA Dataset
class RNADataset(Dataset):
    """
    General CSV loader for RNA secondary structure datasets.
    CSV must contain:
      - sequence
      - dot_bracket
    """
    def __init__(self, data_source, max_len=10000000):
        if isinstance(data_source, str):
            # if a path is provided, load the csv
            df = pd.read_csv(data_source)
        elif isinstance(data_source, pd.DataFrame):
            # if a DataFrame is provided, use it directly
            df = data_source
        else:
            raise ValueError("data_source must be a path or a DataFrame")
        
        if not {"sequence", "dot_bracket"}.issubset(df.columns):
            raise ValueError("CSV must contain 'sequence' and 'dot_bracket' columns")

        initial_len = len(df)
        df = df[df["sequence"].str.len() <= max_len]
        print(f"Loaded {data_source}: Kept {len(df)}/{initial_len} sequences (<= {max_len}nt)")
        self.seqs = df["sequence"].astype(str).tolist()
        self.dbs = df["dot_bracket"].astype(str).tolist()

    def __len__(self):
        return len(self.seqs)

    def __getitem__(self, idx):
        seq = self.seqs[idx]
        db = self.dbs[idx]

        encoded = encode_sequence(seq)
        mat = dotbracket_to_matrix(db)

        return encoded, mat


# collate for variable length
def collate_rna_batch(batch):
    seqs, mats = zip(*batch)
    lengths = [len(s) for s in seqs]

    Lmax = max(lengths)
    B = len(seqs)

    input_ids = torch.zeros((B, Lmax), dtype=torch.long)
    mask = torch.zeros((B, Lmax), dtype=torch.bool)
    targets = torch.zeros((B, Lmax, Lmax), dtype=torch.float32)

    for i, (seq, mat) in enumerate(batch):
        L = len(seq)
        input_ids[i, :L] = seq
        mask[i, :L] = True
        targets[i, :L, :L] = mat

    return input_ids, mask, targets
