import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import argparse
import numpy as np

from dataset import RNADataset, collate_rna_batch
from decoder import pairs_to_matrix, greedy_decode


# model architecture
class RNNModel(nn.Module):
    def __init__(self, embed_dim=16, hidden_dim=64):
        super().__init__()
        self.embedding = nn.Embedding(4, embed_dim)
        self.rnn = nn.GRU(embed_dim, hidden_dim, batch_first=True)
        self.proj = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, x):
        h = self.embedding(x)
        h, _ = self.rnn(h)
        h2 = self.proj(h)
        return torch.matmul(h2, h2.transpose(1, 2))


class LSTMModel(nn.Module):
    def __init__(self, embed_dim=16, hidden_dim=64):
        super().__init__()
        self.embedding = nn.Embedding(4, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.proj = nn.Linear(hidden_dim * 2, hidden_dim)

    def forward(self, x):
        h = self.embedding(x)
        h, _ = self.lstm(h)
        h2 = self.proj(h)
        return torch.matmul(h2, h2.transpose(1, 2))



# metrics
def compare_pair_matrices(true_mat, pred_mat):

    if not isinstance(true_mat, torch.Tensor):
        true_mat = torch.tensor(true_mat)
    if not isinstance(pred_mat, torch.Tensor):
        pred_mat = torch.tensor(pred_mat)

    triu = torch.triu(torch.ones_like(true_mat), diagonal=1).bool()

    true_pairs = true_mat.bool() & triu
    pred_pairs = pred_mat.bool() & triu

    TP = (true_pairs & pred_pairs).sum().item()
    FP = ((~true_pairs) & pred_pairs).sum().item()
    FN = (true_pairs & (~pred_pairs)).sum().item()

    precision = TP / (TP + FP) if (TP + FP) > 0 else 0.0
    recall    = TP / (TP + FN) if (TP + FN) > 0 else 0.0
    f1        = 2*TP / (2*TP + FP + FN) if (2*TP + FP + FN) > 0 else 0.0

    return {
        "TP": TP, "FP": FP, "FN": FN,
        "Precision": precision,
        "Recall":    recall,
        "F1":        f1,
    }


# evaluation loop
def evaluate(model, dataset):

    loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_rna_batch)

    total_tp = total_fp = total_fn = 0
    total_prec = total_rec = total_f1 = 0
    count = 0

    for input_ids, mask, targets in loader:

        with torch.no_grad():
            prob = model(input_ids)[0]

        L = mask.sum().item()
        prob_mat = torch.sigmoid(prob[:L, :L])         # probability matrix

        score_mat = (prob_mat * 100).int()
        predicted_pairs = greedy_decode(score_mat)
        pred_mat_np = pairs_to_matrix(predicted_pairs, L)
        pred_bin = torch.from_numpy(pred_mat_np).float()
        true_mat = targets[0, :L, :L]
        metrics = compare_pair_matrices(true_mat, pred_bin)

        total_tp += metrics["TP"]
        total_fp += metrics["FP"]
        total_fn += metrics["FN"]
        total_prec += metrics["Precision"]
        total_rec += metrics["Recall"]
        total_f1 += metrics["F1"]
        count += 1

    print("\n==== MACRO EVALUATION RESULTS ====")
    print(f"Average Precision = {total_prec / count:.4f}")
    print(f"Average Recall    = {total_rec / count:.4f}")
    print(f"Average F1 Score  = {total_f1 / count:.4f}")
    print(f"(TP={total_tp}, FP={total_fp}, FN={total_fn})")

    

    micro_precision = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0.0
    micro_recall = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0.0
    if micro_precision + micro_recall == 0:
        micro_f1 = 0.0
    else:
        micro_f1 = 2 * (micro_precision * micro_recall) / (micro_precision + micro_recall)
        
    print("\n==== MICRO EVALUATION RESULTS ====")
    print(f"Micro Precision = {micro_precision:.4f}")
    print(f"Micro Recall    = {micro_recall:.4f}")
    print(f"Micro F1 Score  = {micro_f1:.4f}")



if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--dataset", type=str, required=True)
    parser.add_argument("--test_path", type=str, required=True)
    args = parser.parse_args()

    if "rnn" in args.model.lower():
        model = RNNModel()
    else:
        model = LSTMModel()

    model.load_state_dict(torch.load(args.model, map_location="cpu"))
    model.eval()

    dataset = RNADataset(args.test_path)

    # debug print
    sample = dataset[0]
    X, mask, Y = sample
    with torch.no_grad():
        P = model(X.unsqueeze(0))[0]

    print("\n=== MODEL OUTPUT DEBUG ===")
    print("Shape:", P.shape)
    print("Min:", float(P.min()))
    print("Max:", float(P.max()))
    print(P[:5, :5])
    print("======================================\n")

    evaluate(model, dataset)
