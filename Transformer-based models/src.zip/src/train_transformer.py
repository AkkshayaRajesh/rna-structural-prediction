# src/train_transformer.py
from __future__ import annotations

import argparse
import os
import random
import time
from typing import Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .data_utils import ArchiveIIDataset, archive_collate_fn
from .models import RNATransformer, RNATransformerConfig
from .models.pretrained_rna import PretrainedRNAConfig, PretrainedRNAPairwise
from .decoder import decode_with_nussinov


# ============================================================
#  Utility: Seed & Device
# ============================================================

def set_seed(seed: int = 42) -> None:
    """Set random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ============================================================
#  Loss & Metrics
# ============================================================

_bce = nn.BCELoss(reduction="none")


def pairwise_bce_loss(
    P: torch.Tensor,          # (B, L, L) predicted probabilities
    y: torch.Tensor,          # (B, L, L) ground truth (0/1)
    pair_mask: torch.Tensor,  # (B, L, L) bool, valid positions
) -> torch.Tensor:
    """
    Binary cross-entropy on the pairwise matrix.

    We:
    - use only valid positions (pair_mask)
    - use only upper triangle (i < j)
    """
    loss_mat = _bce(P, y)  # (B, L, L)

    # Upper triangle only (i < j)
    upper = torch.triu(torch.ones_like(pair_mask, dtype=torch.bool), diagonal=1)
    m = pair_mask & upper

    if m.sum() == 0:
        return loss_mat.mean()

    loss = loss_mat[m].mean()
    return loss


def batch_ppv_recall_f1(
    P: torch.Tensor,          # (B, L, L)
    y: torch.Tensor,          # (B, L, L)
    pair_mask: torch.Tensor,  # (B, L, L)
    threshold: float = 0.5,
) -> Tuple[float, float, float]:
    """
    Compute batch-averaged PPV, Recall, and F1 from pairwise probabilities.

    - Restrict to upper triangle (i < j)
    - Use only positions where pair_mask=True
    - Predict a pair when P >= threshold
    """
    with torch.no_grad():
        upper = torch.triu(torch.ones_like(pair_mask, dtype=torch.bool), diagonal=1)
        m = pair_mask & upper  # (B, L, L) bool

        if m.sum() == 0:
            return 0.0, 0.0, 0.0

        P_bin = (P >= threshold).float()

        y_true = y[m]      # (N,)
        y_pred = P_bin[m]  # (N,)

        true_pos = (y_true == 1).sum().item()
        pred_pos = (y_pred == 1).sum().item()
        tp = ((y_true == 1) & (y_pred == 1)).sum().item()

        if pred_pos > 0:
            ppv = tp / pred_pos
        else:
            ppv = 0.0

        if true_pos > 0:
            rec = tp / true_pos
        else:
            rec = 0.0

        if ppv + rec > 0:
            f1 = 2 * ppv * rec / (ppv + rec)
        else:
            f1 = 0.0

    return float(ppv), float(rec), float(f1)


# ============================================================
#  Train / Eval Loops
# ============================================================

def train_one_epoch(
    model: torch.nn.Module,
    dataloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    model_type: str,
) -> float:
    """Run one epoch of supervised training with pairwise BCE loss."""
    model.train()
    total_loss = 0.0
    total_samples = 0

    num_batches = len(dataloader)
    for b_idx, batch in enumerate(dataloader, start=1):
        x, mask, y, lengths, ids, seqs, structs = batch
        mask = mask.to(device)
        y = y.to(device)

        if model_type == "transformer":
            x = x.to(device)
            outputs: Dict[str, torch.Tensor] = model(x, mask)
        else:
            # Pretrained model takes raw sequence strings + mask
            outputs: Dict[str, torch.Tensor] = model(seqs, mask)

        P = outputs["pair_probs"]         # (B, L, L)
        pair_mask = outputs["pair_mask"]  # (B, L, L)

        loss = pairwise_bce_loss(P, y, pair_mask)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        bs = mask.size(0)
        total_loss += loss.item() * bs
        total_samples += bs

        if b_idx % 10 == 0 or b_idx == num_batches:
            print(
                f"  [train] batch {b_idx}/{num_batches}  loss={loss.item():.4f}",
                flush=True,
            )

    avg_loss = total_loss / max(total_samples, 1)
    return avg_loss


@torch.no_grad()
def eval_one_epoch(
    model: torch.nn.Module,
    dataloader: DataLoader,
    device: torch.device,
    model_type: str,
    threshold: float,
) -> Dict[str, float]:
    """
    Evaluation step.

    We compute:
    - BCE loss
    - PPV / Recall / F1
    - true pair rate (fraction of true pairs among valid positions)
    - predicted pair rate (fraction of predicted pairs among valid positions)
    """
    model.eval()
    total_loss = 0.0
    total_samples = 0
    sum_ppv = 0.0
    sum_rec = 0.0
    sum_f1 = 0.0
    nb = 0

    sum_true_pos = 0.0
    sum_pred_pos = 0.0
    sum_pairs = 0.0

    for batch in dataloader:
        x, mask, y, lengths, ids, seqs, structs = batch
        mask = mask.to(device)
        y = y.to(device)

        if model_type == "transformer":
            x = x.to(device)
            outputs: Dict[str, torch.Tensor] = model(x, mask)
        else:
            outputs: Dict[str, torch.Tensor] = model(seqs, mask)

        P = outputs["pair_probs"]
        pair_mask = outputs["pair_mask"]

        loss = pairwise_bce_loss(P, y, pair_mask)

        bs = mask.size(0)
        total_loss += loss.item() * bs
        total_samples += bs

        # Pair-rate stats (upper triangle only)
        upper = torch.triu(torch.ones_like(pair_mask, dtype=torch.bool), diagonal=1)
        m = pair_mask & upper
        num_pairs = m.sum().item()
        if num_pairs > 0:
            sum_pairs += num_pairs
            y_true_flat = y[m]
            P_bin = (P >= threshold).float()
            y_pred_flat = P_bin[m]
            sum_true_pos += y_true_flat.sum().item()
            sum_pred_pos += y_pred_flat.sum().item()

        ppv, rec, f1 = batch_ppv_recall_f1(P, y, pair_mask, threshold=threshold)
        sum_ppv += ppv
        sum_rec += rec
        sum_f1 += f1
        nb += 1

    true_rate = sum_true_pos / sum_pairs if sum_pairs > 0 else 0.0
    pred_rate = sum_pred_pos / sum_pairs if sum_pairs > 0 else 0.0

    return {
        "loss": total_loss / max(total_samples, 1),
        "ppv": sum_ppv / max(nb, 1),
        "recall": sum_rec / max(nb, 1),
        "f1": sum_f1 / max(nb, 1),
        "true_rate": true_rate,
        "pred_rate": pred_rate,
    }


# ============================================================
#  Argparse
# ============================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train RNA Transformer or pretrained encoder on ArchiveII"
    )

    # Data paths
    parser.add_argument(
        "--train_csv",
        type=str,
        default="data/archiveII/processed/archiveII_train.csv",
        help="Path to ArchiveII train CSV.",
    )
    parser.add_argument(
        "--val_csv",
        type=str,
        default="data/archiveII/processed/archiveII_val.csv",
        help="Path to ArchiveII validation CSV.",
    )
    parser.add_argument(
        "--test_csv",
        type=str,
        default="data/archiveII/processed/archiveII_test.csv",
        help="Path to ArchiveII test CSV.",
    )

    # Model choice
    parser.add_argument(
        "--model_type",
        type=str,
        choices=["transformer", "pretrained"],
        default="transformer",
        help="Which model to train: scratch transformer or pretrained encoder.",
    )
    parser.add_argument(
        "--pretrained_name",
        type=str,
        default="zhihan1996/DNABERT-2-117M",
        help="Hugging Face model name for the pretrained encoder.",
    )

    # Transformer config (for scratch)
    parser.add_argument(
        "--d_model",
        type=int,
        default=256,
        help="Hidden size / embedding dimension.",
    )
    parser.add_argument(
        "--n_heads",
        type=int,
        default=8,
        help="(Currently unused) Number of attention heads.",
    )
    parser.add_argument(
        "--n_layers",
        type=int,
        default=4,
        help="(Currently unused) Number of Transformer encoder layers.",
    )
    parser.add_argument(
        "--dropout",
        type=float,
        default=0.1,
        help="Dropout rate.",
    )
    parser.add_argument(
        "--max_len",
        type=int,
        default=4096,
        help="Max sequence length for positional embeddings / pretrained encoder.",
    )

    # Training
    parser.add_argument(
        "--batch_size",
        type=int,
        default=1,
        help="Batch size.",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=4,
        help="Number of training epochs.",
    )
    parser.add_argument(
        "--lr",
        type=float,
        default=1e-4,
        help="Learning rate.",
    )

    # Threshold for pair prediction
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.5,
        help="Threshold to convert probabilities into binary pairs for metrics.",
    )

    # Misc
    parser.add_argument(
        "--save_dir",
        type=str,
        default="results",
        help="Directory to save checkpoints and logs.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed.",
    )

    return parser.parse_args()


# ============================================================
#  Main
# ============================================================

def main() -> None:
    args = parse_args()
    os.makedirs(args.save_dir, exist_ok=True)
    set_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}", flush=True)

    # -----------------------------
    # Datasets & Dataloaders
    # -----------------------------
    train_ds = ArchiveIIDataset(args.train_csv)
    val_ds = ArchiveIIDataset(args.val_csv)
    test_ds = ArchiveIIDataset(args.test_csv)

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=archive_collate_fn,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=1,
        shuffle=False,
        collate_fn=archive_collate_fn,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=1,
        shuffle=False,
        collate_fn=archive_collate_fn,
    )

    # -----------------------------
    # Model
    # -----------------------------
    if args.model_type == "transformer":
        # Build transformer encoder from scratch
        cfg = RNATransformerConfig(
            vocab_size=5,          # {PAD, A, C, G, U}
            d_model=args.d_model,
            dropout=args.dropout,
            max_len=args.max_len,
        )
        # If you want to expose num_heads / num_layers from args later:
        # cfg.nhead = args.n_heads
        # cfg.num_layers = args.n_layers
        model = RNATransformer(cfg).to(device)
    else:
        # Pretrained nucleotide / genomic encoder
        pt_cfg = PretrainedRNAConfig(
            model_name=args.pretrained_name,
            max_len=args.max_len,
            freeze_encoder=True,
        )
        model = PretrainedRNAPairwise(pt_cfg).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    # ============================================================
    #  Training Loop
    # ============================================================
    best_val_f1 = -1.0
    best_path = os.path.join(args.save_dir, f"best_{args.model_type}.pt")

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss = train_one_epoch(
            model, train_loader, optimizer, device, args.model_type
        )
        val_metrics = eval_one_epoch(
            model, val_loader, device, args.model_type, threshold=args.threshold
        )
        t1 = time.time()

        print(
            f"[Epoch {epoch:02d}] "
            f"train_loss={train_loss:.4f} "
            f"val_loss={val_metrics['loss']:.4f} "
            f"val_ppv={val_metrics['ppv']:.4f} "
            f"val_rec={val_metrics['recall']:.4f} "
            f"val_f1={val_metrics['f1']:.4f} "
            f"val_true_pair_rate={val_metrics['true_rate']:.6f} "
            f"val_pred_pair_rate={val_metrics['pred_rate']:.6f} "
            f"({t1 - t0:.1f}s)",
            flush=True,
        )

        if val_metrics["f1"] > best_val_f1:
            best_val_f1 = val_metrics["f1"]
            torch.save(model.state_dict(), best_path)
            print(
                f"  [*] New best model saved to {best_path} "
                f"(val_f1={best_val_f1:.4f})",
                flush=True,
            )

    # ============================================================
    #  Final Test (using best checkpoint if available)
    # ============================================================
    if os.path.exists(best_path):
        print(f"[TEST] Loading best checkpoint from {best_path}", flush=True)
        state = torch.load(best_path, map_location=device)
        model.load_state_dict(state)

    test_metrics = eval_one_epoch(
        model, test_loader, device, args.model_type, threshold=args.threshold
    )
    print(
        f"[TEST] loss={test_metrics['loss']:.4f} "
        f"ppv={test_metrics['ppv']:.4f} "
        f"recall={test_metrics['recall']:.4f} "
        f"f1={test_metrics['f1']:.4f} "
        f"true_pair_rate={test_metrics['true_rate']:.6f} "
        f"pred_pair_rate={test_metrics['pred_rate']:.6f}",
        flush=True,
    )

    # ============================================================
    #  Decoder Demo: Nussinov on first test sample
    # ============================================================
    model.eval()
    try:
        batch = next(iter(test_loader))
    except StopIteration:
        print("[Decoder] test_loader is empty, skipping decoding.", flush=True)
        return

    x, mask, y, lengths, ids, seqs, structs = batch
    mask = mask.to(device)

    if args.model_type == "transformer":
        x = x.to(device)
        outputs: Dict[str, torch.Tensor] = model(x, mask)
    else:
        outputs: Dict[str, torch.Tensor] = model(seqs, mask)

    P = outputs["pair_probs"][0].detach().cpu().numpy()  # (L_pad, L_pad)
    L = int(lengths[0].item())
    P = P[:L, :L]

    seq = seqs[0]
    true_db = structs[0]

    pred_db = decode_with_nussinov(
        seq,
        P,
        min_loop_len=3,
        use_rules=True,
        max_decode_len=512,
    )

    print("========== Decoder Demo (first test sample) ==========")
    print(f"ID:        {ids[0]}")
    print(f"Seq (len={len(seq)}):")
    print(seq[:120] + ("..." if len(seq) > 120 else ""))
    print("\nTrue dot-bracket:")
    print(true_db[:160] + ("..." if len(true_db) > 160 else ""))
    print("\nPred dot-bracket (Nussinov on model scores):")
    print(pred_db[:160] + ("..." if len(pred_db) > 160 else ""))
    print("======================================================", flush=True)


if __name__ == "__main__":
    main()
