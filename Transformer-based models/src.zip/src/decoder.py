# src/decoder.py
from __future__ import annotations
from typing import List, Tuple, Optional
import numpy as np

# Canonical + wobble base pairs
_BASE_PAIRS = {
    ("A", "U"), ("U", "A"),
    ("G", "C"), ("C", "G"),
    ("G", "U"), ("U", "G"),
}


def can_pair(b1: str, b2: str, use_rules: bool = True) -> bool:
    """Return True if bases b1 and b2 can form a pair."""
    if not use_rules:
        return True
    return (b1, b2) in _BASE_PAIRS


def nussinov_dp(
    seq: str,
    score_mat: np.ndarray,
    min_loop_len: int = 3,
    use_rules: bool = True,
) -> List[Tuple[int, int]]:
    """
    Nussinov-style dynamic programming for non-pseudoknotted base pairs.

    Args:
        seq:       RNA sequence of length L
        score_mat: (L, L) numpy array of pairing scores
        min_loop_len: minimum separation j - i for a valid pair
        use_rules: whether to enforce base-pairing rules

    Returns:
        List of base pairs (i, j) with 0-based indices and i < j.
    """
    n = len(seq)
    if n == 0:
        return []

    # DP table and backtrace info
    dp = np.zeros((n, n), dtype=np.float32)
    bt: List[List[Optional[Tuple[str, int]]]] = [
        [None] * n for _ in range(n)
    ]

    # Segment length l = j - i
    for l in range(1, n):
        for i in range(0, n - l):
            j = i + l

            # 1) i is unpaired
            best = dp[i + 1, j]
            choice: Tuple[str, int] = ("SKIP_I", -1)

            # 2) j is unpaired
            if dp[i, j - 1] > best:
                best = dp[i, j - 1]
                choice = ("SKIP_J", -1)

            # 3) pair (i, j)
            if j - i > min_loop_len and can_pair(seq[i], seq[j], use_rules):
                val = dp[i + 1, j - 1] + float(score_mat[i, j])
                if val > best:
                    best = val
                    choice = ("PAIR", -1)

            # 4) split interval [i, j] at k
            for k in range(i + 1, j):
                val = dp[i, k] + dp[k + 1, j]
                if val > best:
                    best = val
                    choice = ("SPLIT", k)

            dp[i, j] = best
            bt[i][j] = choice

    # Traceback to recover pairs
    pairs: List[Tuple[int, int]] = []

    def traceback(i: int, j: int) -> None:
        if i >= j:
            return
        choice = bt[i][j]
        if choice is None:
            return
        typ, k = choice
        if typ == "SKIP_I":
            traceback(i + 1, j)
        elif typ == "SKIP_J":
            traceback(i, j - 1)
        elif typ == "PAIR":
            pairs.append((i, j))
            traceback(i + 1, j - 1)
        elif typ == "SPLIT":
            traceback(i, k)
            traceback(k + 1, j)
        else:
            return

    traceback(0, n - 1)
    pairs.sort()
    return pairs


def pairs_to_dotbracket(n: int, pairs: List[Tuple[int, int]]) -> str:
    """
    Convert a list of base pairs into a dot-bracket string.

    Args:
        n:     sequence length
        pairs: list of (i, j) with 0-based indices and i < j

    Returns:
        Dot-bracket string of length n.
    """
    chars = ["." for _ in range(n)]
    for i, j in pairs:
        if 0 <= i < n and 0 <= j < n and i < j:
            chars[i] = "("
            chars[j] = ")"
    return "".join(chars)


def decode_with_nussinov(
    seq: str,
    pair_probs: np.ndarray,
    min_loop_len: int = 3,
    use_rules: bool = True,
    max_decode_len: Optional[int] = None,
) -> str:
    """
    Convenience function: (sequence, pair probability matrix) → dot-bracket.

    If max_decode_len is set and L > max_decode_len, only the first
    max_decode_len positions are decoded and the rest are filled with '.'.
    """
    L = len(seq)
    if max_decode_len is not None and L > max_decode_len:
        L_use = max_decode_len
        seq_use = seq[:L_use]
        P_use = pair_probs[:L_use, :L_use]
    else:
        L_use = L
        seq_use = seq
        P_use = pair_probs

        # Run Nussinov DP on the truncated/whole sequence
    pairs = nussinov_dp(
        seq_use,
        P_use,
        min_loop_len=min_loop_len,
        use_rules=use_rules,
    )
    db = pairs_to_dotbracket(L_use, pairs)

    # If only the first part was decoded, pad the tail with dots
    if L_use < L:
        db = db + "." * (L - L_use)
    return db
