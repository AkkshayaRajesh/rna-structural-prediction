# src/data_utils.py
from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from torch.utils.data._utils.collate import default_collate


# ================================
#  Base encoding
# ================================

# 0 : PAD
# 1 : A
# 2 : C
# 3 : G
# 4 : U
BASE2IDX = {
    "A": 1,
    "C": 2,
    "G": 3,
    "U": 4,
}


def encode_sequence(seq: str) -> torch.Tensor:
    """
    Encode an RNA sequence into an integer tensor.
    - convert to upper case
    - replace T -> U
    - any non {A, C, G, U} base is mapped to 0 (PAD / unknown)
    """
    seq = seq.upper().replace("T", "U")
    ids = [BASE2IDX.get(b, 0) for b in seq]
    return torch.tensor(ids, dtype=torch.long)


# ================================
#  Dot-bracket → pair matrix
# ================================

def dotbracket_to_pairs(db: str) -> List[Tuple[int, int]]:
    """
    Parse a simple dot-bracket string and return a list of base pairs (i, j).
    Indices are 0-based and we enforce i < j.
    """
    stack: List[int] = []
    pairs: List[Tuple[int, int]] = []
    for i, ch in enumerate(db):
        if ch == "(":
            stack.append(i)
        elif ch == ")":
            if stack:
                j = i
                i0 = stack.pop()
                pairs.append((i0, j))
            else:
                # ignore unmatched closing parenthesis
                continue
        else:
            # '.' and any other characters are ignored
            continue
    # sort so that i < j in ascending order
    pairs.sort()
    return pairs


def pairs_to_matrix(n: int, pairs: List[Tuple[int, int]]) -> np.ndarray:
    """
    Convert a list of base pairs (i, j) into an (n, n) 0/1 matrix.
    The matrix is filled symmetrically at (i, j) and (j, i).
    """
    mat = np.zeros((n, n), dtype=np.float32)
    for i, j in pairs:
        if 0 <= i < n and 0 <= j < n and i < j:
            mat[i, j] = 1.0
            mat[j, i] = 1.0
    return mat


# ================================
#  Dataset
# ================================

class ArchiveIIDataset(Dataset):
    """
    Dataset for ArchiveII CSV files.

    The CSV is expected to contain at least:
        - sequence_id
        - sequence
        - dot_bracket

    __getitem__ returns:
        x       : (L,) long        token ids
        mask    : (L,) bool        True = valid position
        y       : (L, L) float32   pair label matrix (0/1)
        length  : scalar tensor    sequence length L
        seq_id  : str
        seq_str : str
        db_str  : str (dot-bracket)
    """

    def __init__(self, csv_path: str):
        super().__init__()
        self.csv_path = csv_path

        df = pd.read_csv(csv_path)
        # Require these three columns
        required_cols = {"sequence_id", "sequence", "dot_bracket"}
        missing = required_cols - set(df.columns)
        if missing:
            raise ValueError(f"{csv_path} is missing columns: {missing}")

        # Drop rows with missing sequence or structure
        df = df.dropna(subset=["sequence", "dot_bracket"])
        df = df.reset_index(drop=True)

        self.df = df

        # Print simple length statistics for logging
        lengths = df["sequence"].astype(str).str.len().to_numpy()
        n = len(df)
        min_len = int(lengths.min()) if n > 0 else 0
        max_len = int(lengths.max()) if n > 0 else 0
        mean_len = float(lengths.mean()) if n > 0 else 0.0

        print(
            f"[ArchiveIIDataset] {csv_path} | "
            f"samples={n}, min_len={min_len}, max_len={max_len}, mean_len={mean_len:.1f}",
            flush=True,
        )

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        seq_id = str(row["sequence_id"])
        seq_str = str(row["sequence"])
        db_str = str(row["dot_bracket"])

        # Ensure sequence and dot-bracket have the same length
        L_seq = len(seq_str)
        L_db = len(db_str)
        if L_seq != L_db:
            # If lengths differ, conservatively truncate to the minimum
            L = min(L_seq, L_db)
            seq_str = seq_str[:L]
            db_str = db_str[:L]
        else:
            L = L_seq

        # Encode input sequence
        x = encode_sequence(seq_str)          # (L,)
        mask = torch.ones(L, dtype=torch.bool)

        # Build target pair matrix
        pairs = dotbracket_to_pairs(db_str)
        y_mat = pairs_to_matrix(L, pairs)     # (L, L) numpy
        y = torch.from_numpy(y_mat)          # (L, L) float32

        length = torch.tensor(L, dtype=torch.long)

        return x, mask, y, length, seq_id, seq_str, db_str


# ================================
#  Collate function
# ================================

def archive_collate_fn(batch):
    """
    Collate function for ArchiveIIDataset.

    Input batch is a list of:
        (x, mask, y, length, seq_id, seq_str, db_str)

    Returns:
        x_pad    : (B, L_max) long
        mask_pad : (B, L_max) bool
        y_pad    : (B, L_max, L_max) float32
        lengths  : (B,) long
        ids      : list[str]
        seqs     : list[str]
        structs  : list[str]
    """
    xs, masks, ys, lengths, ids, seqs, structs = zip(*batch)

    # Convert lengths to tensor
    lengths = torch.tensor(
        [int(l.item()) if torch.is_tensor(l) else int(l) for l in lengths],
        dtype=torch.long,
    )
    B = len(xs)
    L_max = int(lengths.max().item()) if B > 0 else 0

    # Initialize padded tensors
    x_pad = torch.zeros((B, L_max), dtype=torch.long)
    mask_pad = torch.zeros((B, L_max), dtype=torch.bool)
    y_pad = torch.zeros((B, L_max, L_max), dtype=torch.float32)

    for i in range(B):
        L = int(lengths[i].item())
        x_i = xs[i]
        m_i = masks[i]
        y_i = ys[i]

        x_pad[i, :L] = x_i
        mask_pad[i, :L] = m_i
        y_pad[i, :L, :L] = y_i

    # ids, seqs, structs are kept as lists of strings
    return x_pad, mask_pad, y_pad, lengths, list(ids), list(seqs), list(structs)
