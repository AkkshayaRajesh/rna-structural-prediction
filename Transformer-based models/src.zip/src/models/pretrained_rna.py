# src/models/pretrained_rna.py

from typing import Dict, List
import torch
import torch.nn as nn

try:
    from transformers import AutoModel, AutoTokenizer
except ImportError:
    raise ImportError(
        "This module requires the `transformers` library. "
        "Please install it first with `pip install transformers`."
    )


class PretrainedRNAConfig:
    """Configuration for the pretrained RNA/genomic encoder."""

    def __init__(
        self,
        model_name: str = "InstaDeepAI/nucleotide-transformer-v2-50m-multi-species",
        max_len: int = 4096,
        freeze_encoder: bool = True,
    ):
        self.model_name = model_name
        self.max_len = max_len
        self.freeze_encoder = freeze_encoder


class PretrainedRNAPairwise(nn.Module):
    """
    Pretrained nucleotide encoder + pairwise bilinear head.

    Inputs:
        seqs: list of raw RNA sequences (strings)
        mask: (B, L) bool tensor indicating valid (non-padding) positions
    """

    def __init__(self, config: PretrainedRNAConfig):
        super().__init__()
        self.config = config

        # Load HuggingFace tokenizer and encoder
        self.tokenizer = AutoTokenizer.from_pretrained(config.model_name)
        self.encoder = AutoModel.from_pretrained(config.model_name)

        d_model = self.encoder.config.hidden_size

        # Optionally freeze encoder parameters
        if config.freeze_encoder:
            for p in self.encoder.parameters():
                p.requires_grad = False

        # Pairwise bilinear head: score(i, j) = h_i^T W h_j
        self.W = nn.Parameter(torch.randn(d_model, d_model))

    def forward(self, seqs: List[str], mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        device = mask.device
        B, L = mask.shape

        # Map RNA sequence (U) to DNA style (T) if needed
        seqs_dna = [s.upper().replace("U", "T") for s in seqs]

        # Tokenize sequences
        enc_inputs = self.tokenizer(
            list(seqs_dna),
            return_tensors="pt",
            padding="longest",
            truncation=True,
            max_length=self.config.max_len,
        ).to(device)

        # Run encoder
        outputs = self.encoder(**enc_inputs)
        H_enc = outputs.last_hidden_state  # (B, L_enc, d_model)
        B_enc, L_enc, d_model = H_enc.shape

        # Match encoder length to mask length L (truncate or pad)
        use_len = min(L, L_enc)
        H = H_enc[:, :use_len, :]  # (B, use_len, d_model)

        if use_len < L:
            pad = torch.zeros(B, L - use_len, d_model, device=device)
            H = torch.cat([H, pad], dim=1)  # (B, L, d_model)

        # Bilinear pairwise scoring
        scores = torch.einsum("bid,dk,bjd->bij", H, self.W, H)  # (B, L, L)
        P = torch.sigmoid(scores)

        # Pairwise mask: valid positions only, no self-pairs (i != j)
        pair_mask = mask.unsqueeze(1) & mask.unsqueeze(2)  # (B, L, L)
        diag = torch.eye(L, device=device, dtype=torch.bool).unsqueeze(0)
        pair_mask = pair_mask & (~diag)

        return {
            "hidden": H,
            "pair_probs": P,
            "pair_mask": pair_mask,
        }
