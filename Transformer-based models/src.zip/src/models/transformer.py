# src/models/transformer.py

from typing import Dict
import torch
import torch.nn as nn

# A:0, C:1, G:2, U:3
VOCAB_SIZE = 4


class RNATransformerConfig:
    """Configuration for the RNA transformer encoder."""

    def __init__(
        self,
        vocab_size: int = VOCAB_SIZE,
        d_model: int = 256,
        nhead: int = 8,
        num_layers: int = 4,
        dim_feedforward: int = 512,
        dropout: float = 0.1,
        max_len: int = 4096,
    ):
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.nhead = nhead
        self.num_layers = num_layers
        self.dim_feedforward = dim_feedforward
        self.dropout = dropout
        self.max_len = max_len


class PairwiseBilinearHead(nn.Module):
    """
    Head that maps transformer hidden states (B, L, d)
    to a base-pair probability matrix P (B, L, L).
    """

    def __init__(self, d_model: int):
        super().__init__()
        self.W = nn.Parameter(torch.randn(d_model, d_model))

    def forward(self, H: torch.Tensor, mask: torch.Tensor):
        """
        Args:
            H:    (B, L, d_model)
            mask: (B, L) bool, True = valid, False = padding

        Returns:
            P:         (B, L, L) in [0, 1]
            pair_mask: (B, L, L) bool, valid pair positions
                       (exclude padding and diagonal i == j)
        """
        B, L, d = H.shape
        scores = torch.einsum("bid,dk,bjd->bij", H, self.W, H)  # (B, L, L)
        P = torch.sigmoid(scores)

        # Valid positions only, no self-pairs
        pair_mask = mask.unsqueeze(1) & mask.unsqueeze(2)  # (B, L, L)
        diag = torch.eye(L, device=H.device, dtype=torch.bool).unsqueeze(0)
        pair_mask = pair_mask & (~diag)

        return P, pair_mask


class RNATransformer(nn.Module):
    """
    Transformer encoder for RNA sequences plus a pairwise bilinear head
    to produce base-pair probability matrices.
    """

    def __init__(self, config: RNATransformerConfig):
        super().__init__()
        self.config = config

        # Token and positional embeddings
        self.token_emb = nn.Embedding(config.vocab_size, config.d_model)
        self.pos_emb = nn.Embedding(config.max_len, config.d_model)

        # Transformer encoder stack
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.d_model,
            nhead=config.nhead,
            dim_feedforward=config.dim_feedforward,
            dropout=config.dropout,
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=config.num_layers,
        )

        # Pairwise head on top of encoder outputs
        self.pairwise_head = PairwiseBilinearHead(config.d_model)

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            x:    (B, L) long tensor with token ids in {0, 1, 2, 3}
            mask: (B, L) bool tensor, True = valid, False = padding

        Returns:
            dict with keys:
                "hidden":     encoder hidden states (B, L, d_model)
                "pair_probs": base-pair probability matrix (B, L, L)
                "pair_mask":  valid pair mask (B, L, L) bool
        """
        device = x.device
        B, L = x.shape

        # Position indices (wrap around if L > max_len)
        max_len = self.config.max_len
        pos_idx = torch.arange(L, device=device)
        if L > max_len:
            pos_idx = pos_idx % max_len
        positions = pos_idx.unsqueeze(0).expand(B, L)

        tok = self.token_emb(x)       # (B, L, d)
        pos = self.pos_emb(positions) # (B, L, d)
        H = tok + pos                 # (B, L, d)

        # True = padding for src_key_padding_mask
        src_key_padding_mask = ~mask  # (B, L)
        H = self.encoder(H, src_key_padding_mask=src_key_padding_mask)

        P, pair_mask = self.pairwise_head(H, mask)

        return {
            "hidden": H,
            "pair_probs": P,
            "pair_mask": pair_mask,
        }
